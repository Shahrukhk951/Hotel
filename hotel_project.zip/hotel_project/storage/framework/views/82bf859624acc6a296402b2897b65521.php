<!DOCTYPE html>
<html>
  <head> 
   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


   <style type="text/css">
     .table_deg
    {
      border: 2px solid white;
      margin: auto;
      width: 100%;
      text-align: center;
      margin-top: 40px;
    }

    .th_deg
    {
      background-color: skyblue;
      padding: 8px;
    }

    tr
    {
      border: 3px solid white;
    }

    td 
    {
      padding: 10px;
    }

   </style>

  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
      <!-- Sidebar Navigation end-->

       <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">




             <table class="table_deg">
              
              <tr>
                <th class="th_deg">Room_id</th>
                <th class="th_deg">Customer name</th>
                <th class="th_deg">Email</th>
                <th class="th_deg">Phone</th>
                <th class="th_deg">Arrival Date</th>
                <th class="th_deg">Leaving Date</th>
                <th class="th_deg">Status</th>
                <th class="th_deg">Room Title</th>
                <th class="th_deg">Price</th>
                <th class="th_deg">Image</th>
                <th class="th_deg">Delete</th>
                <th class="th_deg">Status Update</th>
              </tr>

              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
              <tr>
                <td><?php echo e($data->room_id); ?></td>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->phone); ?></td>
                <td><?php echo e($data->start_date); ?></td>
                <td><?php echo e($data->end_date); ?></td>
                <td>
                  
                  <?php if($data->status == 'approve'): ?>

                  <span style="color: skyblue;">Approved</span>

                  <?php endif; ?>

                  <?php if($data->status == 'rejected'): ?>

                  <span style="color: red;">Rejected</span>

                  <?php endif; ?>

                  <?php if($data->status == 'waiting'): ?>

                  <span style="color: yellow;">Waiting</span>

                  <?php endif; ?>



                </td>
                <td><?php echo e($data->room->room_title); ?></td>
                <td><?php echo e($data->room->price); ?></td>
                <td>
                  <img style="width: 200!important" src="/room/<?php echo e($data->room->image); ?>">
                </td>
                <td>
                  <a onclick="return confirm('Are you sure to delete this');" class="btn btn-danger" href="<?php echo e(url('delete_booking',$data->id)); ?>">Delete</a>
                </td>

                <td>
                  <span style="padding-bottom: 10px;">

                    <a class="btn btn-success" href="<?php echo e(url('approve_book',$data->id)); ?>">Approve</a>

                  </span>
                  <a class="btn btn-warning" href="<?php echo e(url('reject_book',$data->id)); ?>">Rejected</a>
                </td>
              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

            </table>




    </div>

      </div>

    </div>
     
    
        

        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  </body>
</html><?php /**PATH D:\hotel_project\resources\views/admin/booking.blade.php ENDPATH**/ ?>