<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<link rel="stylesheet" href="<?php echo e(url('public/cssjs/bootstrap.min.css')); ?>" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

 <script src="https://cdn.tailwindcss.com"></script>

<style>


.thumb{
    margin: 10px 5px 0 0;
    width: 300px;
} 
</style>
<body>
<article class="bg-secondary mb-3">  
<div class="card-body text-center">
<h4 class="text-white">Laravel Multiple Image Upload Tutorial With Live Preview</h4>
</div>
</article>
<div class="container">  
    <?php if($message = Session::get('success')): ?>

    <div class="alert alert-success alert-block">

        <button type="button" class="close" data-dismiss="alert">×</button>

            <strong><?php echo e($message); ?></strong>

    </div>
    <br>
    <?php endif; ?>
<form id="file-upload-form" class="uploader" action="<?php echo e(url('add_galary')); ?>" method="post" accept-charset="utf-8" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<input type="file" id="selectImage" name="files[]" multiple />
<span class="text-danger"><?php echo e($errors->first('image')); ?></span>
<div id="thumb-output"></div>
<br>
<button type="submit" class="btn btn-success">Submit</button>
</form>
</div>
</body>


<script>
        selectImage.onchange = evt => {
            preview = document.getElementById('preview');
            preview.style.display = 'block';
            const [file] = selectImage.files
            if (file) {
                preview.src = URL.createObjectURL(file)
            }
        }
    </script>
</html><?php /**PATH D:\hotel_project\resources\views/admin/galary.blade.php ENDPATH**/ ?>