<!DOCTYPE html>
<html>
  <head> 
   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
      <!-- Sidebar Navigation end-->
     
    <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">


            <center>

            <h1 style="font-size: 40px; font-weight: bolder; color: white;">
              Gallary
            </h1>

            <div class="row">

            <?php $__currentLoopData = $gallary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-4">

          
            <img style="height: 200px!important; width: 300px!important;" src="/gallary/<?php echo e($gallary->image); ?>">

            <a class="btn btn-danger" href="<?php echo e(url('delete_gallary',$gallary->id)); ?>">Delete Image</a>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


            <form action="<?php echo e(url('upload_gallary')); ?>" method="Post" enctype="multipart/form-data">

              <?php echo csrf_field(); ?>
              
              <div style="padding: 30px;">

                <label style="color: white; font-weight:bold;">Upload Image</label>

                <input type="file" name="image" required>
            
                 
                <input class="btn btn-primary" type="submit" value="Add Image">
              </div>

            </form>


            </center>

       



         </div>

      </div>

    </div>
        

        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  </body>
</html><?php /**PATH D:\hotel_project\resources\views/admin/gallary.blade.php ENDPATH**/ ?>